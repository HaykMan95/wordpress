	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="footer container-fluid">
			<div class="email-view">
				<div class="input-group mb-3">
				  <input type="text" class="form-control email-input" placeholder="Enter Your Email Address" aria-label="Recipient's username" aria-describedby="basic-addon2">
				  <div class="input-group-append">
				    <button class="btn btn-outline-secondary btn-book" type="button">Book Now</button>
				  </div>
				</div>
				<div class="social">
					<!--Facebook-->
					<div class="btn-social">
						<img src="http://localhost:10080/tutorials/wordpress/wp-content/uploads/2018/02/facebook.png"/>
					</div>
					<!--Twitter-->
					<div class="btn-social">
						<img src="http://localhost:10080/tutorials/wordpress/wp-content/uploads/2018/02/twit.png"/>
					</div>
					<!--Google +-->
					<div class="btn-social">
						<img src="http://localhost:10080/tutorials/wordpress/wp-content/uploads/2018/02/g-.png"/>
					</div>
					<!--Linkedin-->
					<div class="btn-social">
						<img src="http://localhost:10080/tutorials/wordpress/wp-content/uploads/2018/02/lin.png"/>
					</div>
				</div>
			</div>
		</div>
	</footer>

</div><!-- container -->

<?php wp_footer(); ?>

</body>
</html>
